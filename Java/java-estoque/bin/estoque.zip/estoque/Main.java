package estoque;

/**
 * Classe para executar o projeto estoque
 * @author Willian Carlos Gomes
 * @since 18 de fev. de 2021
 */
public class Main {

	/*
	 * M�todo principal para executar a classe
	 */
	public static void main(String[] args) {
		new VendaCarro();

	}

}
